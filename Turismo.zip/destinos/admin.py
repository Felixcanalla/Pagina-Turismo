from django.contrib import admin
from .models import Pais, Destino, SeccionDestino

admin.site.register(Pais)
admin.site.register(Destino)
admin.site.register(SeccionDestino)
